﻿using System;
using System.Data.Entity;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Description;

namespace WebApiApp.Controllers
{
    public class ProductsController : ApiController
    {
        private AppDbContext db = new AppDbContext();

        // GET: api/Products
        public async Task<IHttpActionResult> GetProducts()
        {
            var products = await db.Products.ToListAsync();
            return Ok(products);
        }

        // GET: api/Products/5
        [ResponseType(typeof(Product))]
        public async Task<IHttpActionResult> GetProduct(int? id)
        {
            Product product = await db.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        // GET: api/Products/CategoryId/id
        [Route("api/products/categoryID/{id}")]
        public async Task<IHttpActionResult> GetCategoeyId(int? id)
        {
            Product product = await db.Products.FindAsync(id);
            if (product == null)
            {
                return NotFound();
            }

            return Ok(product);
        }

        // PUT: api/Products/5
        [ResponseType(typeof(void))]
        public async Task<IHttpActionResult> PutProduct(Product product)
        {
            try
            {
                var entry = db.Entry(product);
                db.Entry(product).State = EntityState.Modified;
                await db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                InternalServerError(ex);
            }
            return Ok(product);

        }

        // POST: api/Products
        [ResponseType(typeof(Product))]
        public async Task<IHttpActionResult> PostProduct(Product product)
        {
            try
            {
                db.Products.Add(product);
                await db.SaveChangesAsync();
                return BadRequest(ModelState);
            }
            catch (Exception ex)
            {
                InternalServerError(ex);
            }

            return CreatedAtRoute("DefaultApi", new { id = product.ID }, product);
        }

        // DELETE: api/Products/5
        [ResponseType(typeof(Product))]
        public async Task<IHttpActionResult> DeleteProduct(int id)
        {
            try
            {
                Product product = db.Products.Find(id);
                db.Products.Remove(product);
                await db.SaveChangesAsync();
                return Ok(product);
            }
            catch (Exception ex)
            {
                InternalServerError(ex);
            }
            return BadRequest(ModelState);
        }
    }
}